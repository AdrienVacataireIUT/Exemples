﻿using System;
using System.Collections.Generic;
using Bll;
using ClassLibrary1.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class OffreTests
    {
        [TestMethod]
        public void GetOffres_ReturnsAll()
        {
            Manager m = Manager.Instance;
            var offres = m.GetOffres();
            Assert.IsNotNull(offres != null);
            Assert.IsInstanceOfType(offres, typeof(List<Offre>));
        }
    }
}
