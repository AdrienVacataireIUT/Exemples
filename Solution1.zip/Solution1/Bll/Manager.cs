﻿using Bll.Query;
using ClassLibrary1;
using ClassLibrary1.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bll
{
    public class Manager
    {
        #region Singleton

        private static Manager _instance;
        private Contexte _contexte;

        private Manager()
        {
            _contexte = new Contexte();
        }

        public static Manager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Manager();
                }

                return _instance;
            }
        }

        #endregion

        #region Methods

        public List<Offre> GetOffres()
        {
            return new OffreQuery(_contexte).GetAll().ToList();
        }

        #endregion
    }
}
