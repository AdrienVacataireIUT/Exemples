﻿using ClassLibrary1;
using ClassLibrary1.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bll.Query
{
    public class OffreQuery
    {
        private Contexte _contexte;
        public OffreQuery(Contexte contexte)
        {
            _contexte = contexte;
        }

        public IQueryable<Offre> GetAll()
            => _contexte.Offres;

        public Offre GetById(int id)
            => _contexte.Offres.FirstOrDefault(o => o.OffreId == id);
    }
}
