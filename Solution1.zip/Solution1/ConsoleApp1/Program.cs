﻿using Bll;
using ClassLibrary1;
using ClassLibrary1.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Contexte c = new Contexte();
                //var offres = c.Offres.ToList();

                //Statut s = new Statut { Libelle = "En cours" };
                //Offre o = new Offre { Intitule = "Poste développeur c#", StatutId = 1 };
                //c.Offres.Add(o);
                //c.SaveChanges();

                Manager monManager = Manager.Instance;
                monManager.GetOffres();

                Console.WriteLine("Test");
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}
