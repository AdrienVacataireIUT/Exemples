﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Entities
{
    public class Statut
    {
        [Key()]
        public int StatutId { get; set; }

        public string Libelle { get; set; }

        public ICollection<Offre> Offres { get; set; }
    }
}
