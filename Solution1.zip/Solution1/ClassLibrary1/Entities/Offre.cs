﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Entities
{
    public class Offre
    {
        public int OffreId { get; set; }

        public string Intitule { get; set; }

        public int StatutId { get; set; }

        public Statut Statut { get; set; }
    }
}
