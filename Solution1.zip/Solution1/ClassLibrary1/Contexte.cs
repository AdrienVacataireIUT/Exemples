﻿using ClassLibrary1.Entities;
using ClassLibrary1.Fluent;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Contexte : DbContext
    {
        public Contexte() : base("name=myCs")
        {
            // pour créer / supprimer à chaque fois (debug)
            //Database.SetInitializer<Contexte>(new DropCreateDatabaseIfModelChanges<Contexte>());

            // une fois la base parfaite = on touche plus
            Database.SetInitializer<Contexte>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.HasDefaultSchema("dbo");
            modelBuilder.Configurations.Add(new OffreFluent());
            modelBuilder.Configurations.Add(new StatutFluent());

            //modelBuilder.Configurations.AddFromAssembly(Assembly.GetExecutingAssembly());
        }

        public IDbSet<Offre> Offres { get; set; }

        public IDbSet<Statut> Statuts { get; set; }
    }
}
