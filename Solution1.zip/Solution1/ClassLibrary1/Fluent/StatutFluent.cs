﻿using ClassLibrary1.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Fluent
{
    public class StatutFluent : EntityTypeConfiguration<Statut>
    {
        public StatutFluent()
        {
            ToTable("APP_STATUT");
            HasKey(s => s.StatutId);
            HasKey(s => s.Libelle);
            HasKey(s => new { s.Libelle, s.StatutId });

            Property(s => s.StatutId)
                .IsRequired()
                .HasColumnName("STA_ID")
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(s => s.Libelle)
                .IsRequired()
                .HasMaxLength(50)
                .HasColumnName("STA_LIBELLE");

            HasMany(s => s.Offres).WithRequired(o => o.Statut).HasForeignKey(o => o.StatutId);
        }
    }
}
